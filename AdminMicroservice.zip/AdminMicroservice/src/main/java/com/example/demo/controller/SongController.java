package com.example.demo.controller;


import com.example.demo.entities.Song;

import com.example.demo.service.SongService;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;


@RestController
@RequestMapping("/songs")
public class SongController {

    @Autowired
    private SongService songService;
    
    @GetMapping("/allsongs")
    public ModelAndView getAllSongs() {
    	List<Song> songs=songService.getAllSongs();
    	return new ModelAndView("SongsList","song",songs);
    }

    @GetMapping("/upload")
    public ModelAndView showUploadForm() {
        return new ModelAndView("UploadSong","song",new Song());
    }
    
    @PostMapping(value="/uploadsong")
    public ModelAndView addsong(@ModelAttribute Song song) {
    	songService.saveSong(song);
    	return new ModelAndView("SongsList");
    }
    
    
/*    @PostMapping(value="/upload/song",consumes=MediaType.MULTIPART_FORM_DATA_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
    public String uploadSong(@ModelAttribute Song song,
    		@RequestParam("audioFile") MultipartFile audioFile) throws IOException{
        System.out.println("Sotring data ");
        System.out.println("audio file "+audioFile);
    	if (!audioFile.isEmpty()) {
            song.setAudioFile(audioFile.getBytes());
        }
        songService.saveSong(song);
        return "SongsList";
    }	*/
    
    @GetMapping("/view/{id}")
    public ModelAndView viewSong(@PathVariable("id") Long id) {
        Song song = songService.getSongById(id);
        return new ModelAndView("ViewSong","song",song);
    }
    
    @GetMapping("/update/{id}")
    public ModelAndView getUpdateForm(@PathVariable("id")long id) {
    	Song song = songService.getSongById(id);
    	return new ModelAndView("UpdateSong","song",song);
    }
    
    @PostMapping("updatesong/{id}")
    public ModelAndView updateSong(@PathVariable("id")long id,@ModelAttribute Song song) {
    	songService.updateSong(id, song);
    	return new ModelAndView("redirect:/songs/allsongs");
    	
    }
    
/*    @PutMapping("/{id}/edit")
    public String updateSong(@PathVariable("id") Long id,
                             @ModelAttribute Song song,
                             @RequestParam("audioFile") MultipartFile audioFile) throws IOException {
        if (!audioFile.isEmpty()) {
            song.setAudioFile(audioFile.getBytes());
        }
        songService.updateSong(id, song);
        return "redirect:/songs";
    }	*/
    
    @GetMapping("/delete/{id}")
    public ModelAndView deleteSong(@PathVariable("id") Long id) {
        songService.deleteSong(id);
        return new ModelAndView("redirect:/songs/allsongs");
    }
    @GetMapping("/Songs")
    public List<Song> getSongs(){
    	return songService.getSongs();
    }
    @GetMapping("/Song/{id}")
    public Song getSong(@PathVariable("id")long id) {
    	return songService.getSong(id);
    }
    @GetMapping("/searchMusic/{searchQuery}/{searchBy}")
    public List<Song> searchMusic(@PathVariable("searchQuery")String searchQuery,@PathVariable("searchBy")String searchBy) {

        List<Song> songs = songService.searchSongs(searchQuery, searchBy);
        return songs; // Name of the JSP page to display results
    }
}

