package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.User;
import com.example.demo.exceptions.ResourceNotFoundException;
import com.example.demo.repositories.AdminRepository;

@Service
public class AdminService {

	@Autowired
	AdminRepository adminrepo;
	public User insertAdmin(User u) {
		return adminrepo.save(u);	
	}
	public User retreiveAdminbyid(long id) {
		User user=adminrepo.findById(id).orElseThrow(()->
		new ResourceNotFoundException("there is no admin with that id: "+id));
		return user;
	}
	public List<User> getAllUsers(){
		return adminrepo.findAll();
	}
	public void deleteAdminbyid(long id) {
		if (!adminrepo.existsById(id)) {
            throw new ResourceNotFoundException("admin not found with id: " + id);
        }
		adminrepo.deleteById(id);
	}
	public User updateadminbyid(User u,long  id) {
		User user = adminrepo.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Admin not found with id: "+id));
			user.setMobile(u.getMobile());
			user.setEmail(u.getEmail());
			user.setPassword(u.getPassword());
			user.setRole(u.getRole());
		return adminrepo.save(user);
	}
}
