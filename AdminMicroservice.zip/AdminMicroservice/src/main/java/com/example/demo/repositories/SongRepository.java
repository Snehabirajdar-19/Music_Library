package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Song;

@Repository
public interface SongRepository extends JpaRepository<Song,Long>{
	
	public List<Song> findByIsVisibleTrue();
	
	public List<Song> findByArtistContainingIgnoreCase(String artist);

    public List<Song> findByAlbumContainingIgnoreCase(String album);

    public List<Song> findByMusicDirectorContainingIgnoreCase(String musicDirector);

}
