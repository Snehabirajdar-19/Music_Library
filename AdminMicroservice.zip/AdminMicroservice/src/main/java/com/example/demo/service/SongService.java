package com.example.demo.service;

import com.example.demo.entities.Song;
import com.example.demo.exceptions.InvalidInputException;
import com.example.demo.exceptions.ResourceNotFoundException;
import com.example.demo.repositories.SongRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SongService {

    @Autowired
    private SongRepository songRepository;

    public List<Song> getAllSongs() {
        return songRepository.findAll();
    }

    public Song getSongById(Long id) {
        Optional<Song> song = songRepository.findById(id);
        return song.orElseThrow(() -> new ResourceNotFoundException("Song not found with id: " + id));
    }

    public Song saveSong(Song song) {
        return songRepository.save(song);
    }

    public Song updateSong(Long id, Song songDetails) {
        Song song = getSongById(id);
        song.setTitle(songDetails.getTitle());
        song.setArtist(songDetails.getArtist());
        song.setAlbum(songDetails.getAlbum());
        song.setMusicDirector(songDetails.getMusicDirector());
        song.setAudioFile(songDetails.getAudioFile());
        song.setIsVisible(songDetails.getIsVisible());
        return songRepository.save(song);
    }
    
    public void deleteSong(Long id) {
        if (!songRepository.existsById(id)) {
            throw new ResourceNotFoundException("Song not found with id: " + id);
        }
        songRepository.deleteById(id);
    }
    
    public List<Song> getSongs(){
    	return songRepository.findByIsVisibleTrue();
    }
    public Song getSong(long id) {
    	Song song=songRepository.findById(id).orElseThrow(()->
    	new ResourceNotFoundException("Song not found with id: "+id));
    	return song;
    }
    public List<Song> searchSongs(String searchQuery, String searchBy) {
        switch (searchBy) {
            case "artist":
                return songRepository.findByArtistContainingIgnoreCase(searchQuery);
            case "album":
                return songRepository.findByAlbumContainingIgnoreCase(searchQuery);
            case "musicDirector":
                return songRepository.findByMusicDirectorContainingIgnoreCase(searchQuery);
            default:
                throw new InvalidInputException("Invalid search criteria");
        }
    }
}

