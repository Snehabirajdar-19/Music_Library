package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entities.User;
import com.example.demo.repositories.AdminRepository;

@RestController
@RequestMapping("/Admin")
public class AdminSecurityController {

	@Autowired
	AdminRepository adminRepository;
	@GetMapping("/Validation")
	public ModelAndView getPage(@ModelAttribute("adminObject")User user) {
		User adminforlogin = adminRepository.findByEmail(user.getEmail());
		if((adminforlogin.getEmail().equals(user.getEmail()))&& 
				(adminforlogin.getPassword().equals(user.getPassword())) && 
				(adminforlogin.getRole().equalsIgnoreCase("ADMIN"))) {
			return new ModelAndView("Home");
		}
		return new ModelAndView("Error");
	}
	
}
