package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entities.User;
import com.example.demo.service.AdminService;

@RestController

@RequestMapping("/Admin")
public class AdminController {
	
	@Autowired
	AdminService adminservice;
	
	@GetMapping("/LoginPage")
	public ModelAndView getLoginPage() {
		User user=null;
		return new ModelAndView("NewFile","adminObject",user);
	}
	
	@GetMapping("/RegisterAdmin")
	public ModelAndView getRegistrationPage() {
		return new ModelAndView("RegisterAdmin","admin",new User());
	}
	@PostMapping("/insertAdmin")
	public ModelAndView insertAdmin(@ModelAttribute User admin) {
		adminservice.insertAdmin(admin);
		return new ModelAndView("NewFile");
	}
	
	@GetMapping("/retreiveall")
	public List<User> getAllUsers(){
		return adminservice.getAllUsers();
	}
	
	@GetMapping("/retreiveAdminbyid/{id}")
	public User retreiveAdmin(@PathVariable long id) {
		return adminservice.retreiveAdminbyid(id);
	}
	@DeleteMapping("/deleteadminbyid/{id}")
	public void deletebyid(@PathVariable long id) {
		adminservice.deleteAdminbyid(id);
	}
	@PutMapping("/updateadminbyid/{id}")
	public User updateadminbyid(@RequestBody User u,@PathVariable long id) {
		return adminservice.updateadminbyid(u,id);
	}
}
