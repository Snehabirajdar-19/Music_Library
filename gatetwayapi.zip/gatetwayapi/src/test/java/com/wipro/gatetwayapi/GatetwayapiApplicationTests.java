package com.wipro.gatetwayapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatetwayapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
