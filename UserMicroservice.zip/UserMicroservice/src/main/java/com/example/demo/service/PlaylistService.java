package com.example.demo.service;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Playlist;
import com.example.demo.entities.Song;
import com.example.demo.entities.User;
import com.example.demo.exceptions.InvalidInputException;
import com.example.demo.exceptions.ResourceNotFoundException;
import com.example.demo.repositories.PlaylistRepository;
import com.example.demo.repositories.SongRepository;
import com.example.demo.repositories.UserRepository;

@Service
public class PlaylistService {

	@Autowired
	PlaylistRepository playlistRepository;
	@Autowired
	UserRepository userrepo;
	@Autowired
	SongRepository songRepository;
	
	// Create a new playlist
    public Playlist createPlaylist(Long userId, Playlist playlist) {
        if (playlist.getName() == null || playlist.getName().isEmpty()) {
            throw new InvalidInputException("Playlist name cannot be empty");
        }
        User user = userrepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        playlist.setUser(user);
        return playlistRepository.save(playlist);
    }
    public Playlist addSongToPlaylist(Long playlistId, Long songId) {
        Optional<Playlist> playlist = playlistRepository.findById(playlistId);
        Optional<Song> song = songRepository.findById(songId);

        // Throw custom exceptions if playlist or song is not found
        if (!playlist.isPresent()) {
            throw new ResourceNotFoundException("Playlist not found with id: " + playlistId);
        }

        if (!song.isPresent()) {
            throw new ResourceNotFoundException("Song not found with id: " + songId);
        }

        // Add the song to the playlist and save
        playlist.get().getSongs().add(song.get());
        return playlistRepository.save(playlist.get());
    }
	// Get all playlists for a user
    public List<Playlist> getAllPlaylistsForUser(Long userId) {
        User user = userrepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        return playlistRepository.findByUser(user);
    }

    // Get a specific playlist by ID
    public Playlist getPlaylistById(Long playlistId) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new ResourceNotFoundException("Playlist not found with id: " + playlistId));

        return playlist;
    }

    public List<Playlist> getAllPlaylists() {
        return playlistRepository.findAll();
    }
    
 // Update an existing playlist by its ID
    public Playlist updatePlaylist(Long playlistId, Playlist updatedPlaylistData) {
        if (updatedPlaylistData.getName() == null || updatedPlaylistData.getName().isEmpty()) {
            throw new InvalidInputException("Playlist name cannot be null or empty");
        }

        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new ResourceNotFoundException("Playlist not found with id: " + playlistId));

        playlist.setName(updatedPlaylistData.getName()); // Update playlist name
  //      playlist.setSongs(updatedPlaylistData.getSongs()); // Update playlist songs
        return playlistRepository.save(playlist); // Save the updated playlist
    }

    // Delete a playlist by its ID
    public void deletePlaylist(Long playlistId) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new ResourceNotFoundException("Playlist not found with id: " + playlistId));

        playlistRepository.delete(playlist);
    }
    
    // find playlist by name
    public Playlist findbyname(String name) {
    	return playlistRepository.findByName(name);
    }
    
    public List<Song> getSongsByPlaylistId(Long playlistId) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new ResourceNotFoundException("Playlist not found"));
        return playlist.getSongs(); // Access songs from the playlist
    }
    
    public void deleteSongFromPlaylist(Long playlistId, Long songId) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new ResourceNotFoundException("Playlist not found"));

        // Remove the song from the playlist
        List<Song> songs = playlist.getSongs();
        songs.removeIf(song -> song.getId().equals(songId));

        // Save the updated playlist
        playlist.setSongs(songs);
        playlistRepository.save(playlist);
    }
    
    public List<Song> searchSongsInPlaylist(Long playlistId, String searchQuery) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new ResourceNotFoundException("Playlist not found"));

        return playlist.getSongs().stream()
                .filter(song -> song.getTitle().toLowerCase().contains(searchQuery.toLowerCase()) ||
                                song.getArtist().toLowerCase().contains(searchQuery.toLowerCase())||
                                song.getAlbum().toLowerCase().contains(searchQuery.toLowerCase())||
                                song.getMusicDirector().toLowerCase().contains(searchQuery.toLowerCase()))
                .collect(Collectors.toList());
    }
}
