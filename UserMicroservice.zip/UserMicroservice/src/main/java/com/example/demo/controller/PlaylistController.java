package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entities.Playlist;
import com.example.demo.entities.Song;
import com.example.demo.service.PlaylistService;

@RestController
@RequestMapping("/Playlist")
public class PlaylistController {

	@Autowired
	PlaylistService playlistService;
	
	@GetMapping("/CreatePlaylist")
	public ModelAndView getPage() {
		return new ModelAndView("CreatePlaylist","playlist",new Playlist());
	}
	
	@PostMapping("/users/playlists")
    public ModelAndView createPlaylist(@RequestParam("id") Long id, @ModelAttribute("playlist") Playlist playlist) {
    	playlistService.createPlaylist(id, playlist);
        return new ModelAndView("UserPage");
    }
	
	// Get all playlists
    @GetMapping("/users/getAllPlaylists")
    public ModelAndView getAllPlaylists(){
    	List<Playlist> playlist = playlistService.getAllPlaylists();
    	return new ModelAndView("ListofPlaylist","playlist",playlist);
    }
    
    @RequestMapping("/updatePlaylists/{playlistId}")
    public ModelAndView updateplaylist(@PathVariable("playlistId")long playlistId) {
    	Playlist playlist = playlistService.getPlaylistById(playlistId);
    	return new ModelAndView("UpdatePlaylist","playlist",playlist);
    }
    
    // Update a playlist by its ID
    @GetMapping("/updatePlaylistsById/{playlistId}")
    public ModelAndView updatePlaylist(@PathVariable("playlistId")Long playlistId, @ModelAttribute("playlist")Playlist playlist) {
        playlistService.updatePlaylist(playlistId, playlist);
        return new ModelAndView("UserPage"); // Return 404 if playlist does not exist
    }

    // Delete a playlist by its ID
    @GetMapping("/deletePlaylists/{playlistId}")
    public ModelAndView deletePlaylist(@PathVariable("playlistId")Long playlistId) {
        playlistService.deletePlaylist(playlistId);
        return new ModelAndView("UserPage"); // Return 404 if playlist does not exist
    }

    // Add a song to a playlist
    @PostMapping("/playlists/addSong/{songid}")
    public ModelAndView addSongToPlaylist(@RequestParam("playlistName") String playlistName, @PathVariable("songid") Long songid) {
    	Playlist playlist=playlistService.findbyname(playlistName);
        playlistService.addSongToPlaylist(playlist.getId(), songid);
        return new ModelAndView("UserPage");
    }
    
    // get songs by playlist id
    @GetMapping("/songs/{playlistId}")
    public ModelAndView getSongsFromPlaylist(@PathVariable Long playlistId) {
        List<Song> songs = playlistService.getSongsByPlaylistId(playlistId);
        return new ModelAndView("PlaylistSongs","songs",songs);
    }
    
    // remove the songs from playlist
    @GetMapping("/removesong/playlist/{songId}")
    public ModelAndView deleteSongFromPlaylist(@RequestParam("playlistName")String playlistName, @PathVariable("songId")Long songId) {
    	Playlist playlist=playlistService.findbyname(playlistName);
        playlistService.deleteSongFromPlaylist(playlist.getId(), songId);
        return new ModelAndView("ListofPlaylist"); // Return 204 No Content
    }
    
    // search songs in playlist
    @GetMapping("/playlists/search/{playlistId}")
    public ModelAndView searchSongsInPlaylist(@PathVariable("playlistId")Long playlistId,
                                                             @RequestParam("query")String query) {
        List<Song> songs = playlistService.searchSongsInPlaylist(playlistId, query);
        return new ModelAndView("SearchSongsPlaylist","songs",songs);
    }
    
    // Get all playlists for a specific user
    @GetMapping("/users/{userId}/playlists")
    public ResponseEntity<List<Playlist>> getPlaylistsByUser(@PathVariable Long userId) {
    	List<Playlist> playlists = playlistService.getAllPlaylistsForUser(userId);
        return ResponseEntity.ok(playlists);
    }
    
    // Get a playlist by playlist Id
    @GetMapping("/users/playlists/{playlistId}")
    public ResponseEntity<Playlist> getPlaylistById(@PathVariable Long playlistId) {
    	Playlist playlist = playlistService.getPlaylistById(playlistId);
        return ResponseEntity.ok(playlist);
    }
    
}
