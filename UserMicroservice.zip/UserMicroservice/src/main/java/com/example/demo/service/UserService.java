package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entities.User;
import com.example.demo.repositories.UserRepository;

@Service
public class UserService {
//	@Autowired
//	PasswordEncoder passwordEncoder;
	
	@Autowired
	UserRepository userrepo;
	public User insert(@RequestBody User u) {
//		u.setPassword(passwordEncoder.encode(u.getPassword()));
		return userrepo.save(u);
	}
	public Optional<User> getuserbyid(long id) {
		return userrepo.findById(id);
	}
	public List<User> getallusers(){
		return userrepo.findAll();
	}
	public void deletebyid(long id) {
		userrepo.deleteById(id);
	}
	public User findbyemail(String email) {
		return userrepo.findByEmail(email);
	}
	public User updateuser(long id,User up) {
		Optional<User> user = userrepo.findById(id);
		User us=null;
		if(user.isPresent()) {
			us=user.get();
			us.setEmail(up.getEmail());
			us.setMobile(up.getMobile());
			us.setPassword(up.getPassword());
			us.setRole(up.getRole());
		}
		return userrepo.save(us);
	}
}
