package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entities.User;
import com.example.demo.repositories.UserRepository;


@RestController
@RequestMapping("/User")
public class UserSecurityController {
	
	@Autowired
	UserRepository userRepository;
	@GetMapping("/Validation")
	public ModelAndView getPage(@ModelAttribute("userObject")User user) {
		User userforlogin = userRepository.findByEmail(user.getEmail());
		if((userforlogin.getEmail().equals(user.getEmail()))&& 
				(userforlogin.getPassword().equals(user.getPassword())) && 
				(userforlogin.getRole().equalsIgnoreCase("USER"))) {
			return new ModelAndView("UserPage");
		}
		return new ModelAndView("Error");
	}
	
}
