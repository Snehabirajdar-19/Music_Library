package com.example.demo.service;

import java.util.Arrays;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.entities.SongDTO;
import com.example.demo.repositories.SongRepository;

@Service
public class SongService {

	@Autowired
	SongRepository songRepository;
	
	@Autowired
    private RestTemplate restTemplate;
	
	@Value("${adminmicroservice.url}")
    private String adminMicroserviceUrl;

    public List<SongDTO> getAllSongs() {
        String url = adminMicroserviceUrl + "/Songs";
        SongDTO[] songs = restTemplate.getForObject(url, SongDTO[].class);
        return Arrays.asList(songs);
    }
    
    public SongDTO getDetailsByid(long id) {
    	String url= adminMicroserviceUrl + "/Song/"+id;
    	SongDTO song = restTemplate.getForObject(url, SongDTO.class);
    	return song;
    }

	public List<SongDTO> searchSongs(String searchQuery, String searchBy) {
		String url= adminMicroserviceUrl + "/searchMusic/"+searchQuery+"/"+searchBy;
		SongDTO[] songs = restTemplate.getForObject(url, SongDTO[].class);
		return Arrays.asList(songs);
	}
}
