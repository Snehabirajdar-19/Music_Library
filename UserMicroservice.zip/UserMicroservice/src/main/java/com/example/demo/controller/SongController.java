package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entities.Song;
import com.example.demo.entities.SongDTO;
import com.example.demo.repositories.SongRepository;
import com.example.demo.service.SongService;

@RestController
@RequestMapping("/User")
public class SongController {
	
	@Autowired
	SongService songService;
	@Autowired
	SongRepository songRepository;
	
	@PostMapping("/insertsong")
	public ResponseEntity<Song> insertsong(@RequestBody Song s) {
		return ResponseEntity.ok(songRepository.save(s));
	}
	
	@GetMapping("/getAllSongs")
	public ModelAndView getAllSongs() {
        List<SongDTO> song=songService.getAllSongs();
        return new ModelAndView("SongsList","song",song);
    }
	
	@GetMapping("/ViewDetailsofSong/{id}")
	public ModelAndView getDetailsByid(@PathVariable("id")long id) {
		SongDTO songs = songService.getDetailsByid(id);
		return new ModelAndView("DetailsofSongs","songs",songs);
	}
	@GetMapping("/searchMusic")
    public ModelAndView searchMusic(
        @RequestParam("searchQuery") String searchQuery,
        @RequestParam("searchBy") String searchBy) {

        List<SongDTO> songs = songService.searchSongs(searchQuery, searchBy);
        return new ModelAndView("SearchSongs","songs",songs); 
    }
}
